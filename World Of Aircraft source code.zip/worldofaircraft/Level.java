/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package worldofaircraft;

import physics.Vector;

/**
 *
 * @author Robin
 */
public class Level {
	public static int groundLevel = 10;
	public static int levelWidth = 1000;
	public static int levelHeight = 1000;
	public static Vector initialTranslation = new Vector(0,0);

}
